ANTY'S SAVE EDITOR — PACKAGE-READY PROJECT

This package adds a root-level package.json and Vite/Capacitor configuration so build services that require package.json can recognize the project.

For a Node.js build environment:
  npm install
  npm run build

Vite outputs the built static app to dist/.

For a cloud service that specifically supports Capacitor iOS builds, follow that service's instructions for iOS platform generation and signing. This ZIP does NOT itself contain a signed IPA, Apple signing certificate, or provisioning profile. An IPA still requires a compatible iOS build/signing service and an installation method.

Entry pages: index.html and editor.html.
